const { Server } = require("socket.io");
let IO;

module.exports.initIO = (httpServer) => {
  IO = new Server(httpServer,{ 
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
      allowedHeaders: ["my-custom-header"],
      credentials: true
    }});
   console.log('socket running..')
   IO.use((socket, next) => {
    if (socket.handshake.query) {
      let roomId = socket.handshake.query.roomId;
      socket.room = roomId;
      next();
    }
  });
  
  IO.on("connection", (socket) => {
    console.log(socket.id, "Connected");
    socket.join(socket.user);

 

   
            
    socket.on('broadcast',(leaderData)=>{
      console.log(leaderData.room)
      socket.to(leaderData.room).emit('listening',leaderData)
   
      console.log(leaderData)
      })
        socket.on('join_room', async(data)=> {
             
            socket.join(data.room)
            const roomSize = IO.sockets.adapter.rooms.get(data.room).size || 0;
            console.log('ini room size '+roomSize)
            socket.to(data.room).emit('userCount', roomSize);
            socket.to(data.room).emit('joined',{notification:data.username+ ' joined'})
            console.log(socket.id)
            socket.to(data.room).emit('room_validation',{message: 'succes join to room '+data.room})
            
          
            
          
            socket.on('disconnect', () => {
                const roomSize = IO.sockets.adapter.rooms.get(data.room).size;
                IO.to(data.room).emit('userCount', roomSize);
              });
    
           
           
            
        })
   
  });
};

module.exports.getIO = () => {
  if (!IO) {
    throw Error("IO not initilized.");
  } else {
    return IO;
  }
};
