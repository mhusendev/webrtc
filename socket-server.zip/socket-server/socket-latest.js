const { Server } = require("socket.io");
let IO;

module.exports.initIO = (httpServer) => {
  IO = new Server(httpServer);

  IO.use((socket, next) => {
    if (socket.handshake.query) {
      let roomId = socket.handshake.query.roomId;
      socket.room = roomId;
      next();
    }
  });

  IO.on("connection", (socket) => {
    console.log(socket.room, "Connected");
    socket.join(socket.room);

    socket.on("call", (data) => {
      let roomId = data.roomId;
      let rtcMessage = data.rtcMessage;
      console.log(data)
    //   const roomSize = IO.sockets.adapter.rooms.get(socket.room)?.size || 0;
    //   console.log('ini room size '+roomSize)
    //   socket.to(room).emit('userCount', roomSize);
      socket.to(roomId).emit("newCall", {
        roomId: socket.room,
        rtcMessage: rtcMessage,
      });
    });

    socket.on("answerCall", (data) => {
        console.log(data)
      let roomId = data.roomId;
      rtcMessage = data.rtcMessage;

      socket.to(roomId).emit("callAnswered", {
        roomId: socket.room,
        rtcMessage: rtcMessage,
      });
    });

    socket.on("ICEcandidate", (data) => {
      console.log("ICEcandidate data.roomId", data.roomId);
      let roomId = data.roomId;
      let rtcMessage = data.rtcMessage;
      console.log("socket.room emit", socket.room);

      socket.to(roomId).emit("ICEcandidate", {
        sender: socket.room,
        rtcMessage: rtcMessage,
      });
    });
  });
};

module.exports.getIO = () => {
  if (!IO) {
    throw Error("IO not initilized.");
  } else {
    return IO;
  }
};
