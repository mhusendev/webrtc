const path = require('path');
const { createServer } = require('http');
const cors = require('cors');
const express = require('express');
const { getIO, initIO } = require('./socket');

const app = express();

app.use('/', express.static(path.join(__dirname, 'static')));
app.use(cors())
const httpServer = createServer(app);

let port = process.env.PORT || 9000;

initIO(httpServer);

httpServer.listen(port)
console.log("Server started on ", port);

getIO();