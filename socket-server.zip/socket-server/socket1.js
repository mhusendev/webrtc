const { Server } = require("socket.io");
let IO;

module.exports.initIO = (httpServer) => {
  IO = new Server(httpServer);

  IO.use((socket, next) => {
    if (socket.handshake.query) {
      let roomId = socket.handshake.query.roomId;
      socket.room = roomId;
      next();
    }
  });

  IO.on("connection", (socket) => {
    console.log(socket.room, "Connected");
    socket.join(socket.room);

    socket.on("call", (data) => {
      console.log(data)
      let room = data.roomId;
      let rtcMessage = data.rtcMessage;
      const roomSize = IO.sockets.adapter.rooms.get(socket.room).size || 0;
      console.log('ini room size '+roomSize)
      socket.to(data.room).emit('joined',{notification:data.username+ ' joined'})
      socket.to(room).emit('userCount', roomSize);
      socket.to(room).emit("callAnswered", {
        room: socket.room,
        rtcMessage: rtcMessage,
      });
    });

    socket.on("ICEcandidate", (data) => {
      console.log("ICEcandidate data.roomId", data.roomId);
      let roomId = data.roomId;
      let rtcMessage = data.rtcMessage;
      console.log("socket.user emit", socket.room);

      socket.to(roomId).emit("ICEcandidate", {
        sender: socket.room,
        rtcMessage: rtcMessage,
      });
    });

    socket.on('disconnect', () => {
      const roomSize = IO.sockets.adapter.rooms.get(socket.room).size;
      IO.to(socket.room).emit('userCount', roomSize);
    });
    
    // socket.on("ICEcandidate", (data) => {
    //   console.log("ICEcandidate data.roomId", data.roomId);
    //   let roomId = data.roomId;
    //   let rtcMessage = data.rtcMessage;
    //   console.log("socket.user emit", socket.user);

    //   socket.to(roomId).emit("ICEcandidate", {
    //     sender: socket.user,
    //     rtcMessage: rtcMessage,
    //   });
    // });
  });
};

module.exports.getIO = () => {
  if (!IO) {
    throw Error("IO not initilized.");
  } else {
    return IO;
  }
};
